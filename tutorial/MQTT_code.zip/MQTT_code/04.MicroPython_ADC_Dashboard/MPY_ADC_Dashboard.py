from umqtt.simple import MQTTClient
import xtools, utime
from machine import ADC

adc = ADC(0)
xtools.connect_wifi_led()

ADAFRUIT_IO_USERNAME = "<USERNAME>"
ADAFRUIT_IO_KEY = "<IO_KEY>"
FEED1 = "brightness"

# MQTT 客戶端
client = MQTTClient (
    client_id = xtools.get_id(),
    server = "io.adafruit.com",
    user = ADAFRUIT_IO_USERNAME,
    password = ADAFRUIT_IO_KEY,
    ssl = False,
)

topic1 = ADAFRUIT_IO_USERNAME + "/feeds/" +FEED1

while True:
    print("儲存亮度資料!")
    adc_value = adc.read()
    print(adc_value)
    client.connect()
    client.publish(topic1, str(adc_value))
    client.disconnect()
    utime.sleep(5) 