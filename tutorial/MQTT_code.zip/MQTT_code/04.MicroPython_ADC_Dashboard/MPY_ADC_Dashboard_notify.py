from umqtt.simple import MQTTClient
import xtools, utime
from machine import ADC

adc = ADC(0)
xtools.connect_wifi_led()

ADAFRUIT_IO_USERNAME = "<USERNAME>"
ADAFRUIT_IO_KEY = "<IO_KEY>"
FEED1 = "brightness"
FEED2 = "switch"
FEED3 = "notify"

# MQTT 客戶端
client = MQTTClient (
    client_id = xtools.get_id(),
    server = "io.adafruit.com",
    user = ADAFRUIT_IO_USERNAME,
    password = ADAFRUIT_IO_KEY,
    ssl = False,
)

def sub_cb(topic, msg):
    global topic3, topic2, stop, adc_value
    print("收到訊息: ", msg.decode())
    topic = topic.decode()
    if topic == topic3:
        if msg.decode() == "1":
            token = "<LINE NOTIFY TOKEN>"
            message = "目前亮度: " + str(adc_value)
            xtools.line_msg(token, message)            
    if topic == topic2:
        if msg.decode() == "ON":
            stop = True
        else:
            stop = False
        print("stop=", stop)

client.set_callback(sub_cb)   # 指定回撥函數來接收訊息
client.connect()              # 連線

topic1 = ADAFRUIT_IO_USERNAME + "/feeds/" +FEED1
topic2 = ADAFRUIT_IO_USERNAME + "/feeds/" +FEED2
topic3 = ADAFRUIT_IO_USERNAME + "/feeds/" +FEED3
print(topic2, topic3)
client.subscribe(topic2)      # 訂閱主題
client.subscribe(topic3)      # 訂閱主題

stop = False
adc_value = 0

while True:
    if not stop:
        print("上傳儲存亮度資料!")
        adc_value = adc.read()
        print(adc_value)
        client.publish(topic1, str(adc_value))
    else:
        print("停上上傳亮度資料!")
        
    client.check_msg()    
    utime.sleep(5) 