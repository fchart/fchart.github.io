import paho.mqtt.client as mqtt
import requests

ADAFRUIT_IO_USERNAME = "<USERNAME>"
ADAFRUIT_IO_KEY = "<IO_KEY>"
FEED1 = "request"
FEED2 = "result"

def getTrain(s_number):    
    headers = {'user-agent':'Mozilla/5.0'}
    # https://tdx.transportdata.tw/api/basic/v2/Rail/TRA/GeneralTrainInfo/TrainNo/1202?$format=JSON
    tdx_url = ("https://tdx.transportdata.tw/api/basic"
               "/v2/Rail/TRA/GeneralTrainInfo/TrainNo/"
               + str(s_number) +"?$format=JSON")

    r = requests.get(tdx_url, headers=headers)
    if(r.status_code == 200):
        data = r.json()
        msg = "\n車號:" + s_number + "\n  "
        msg += data[0]['StartingStationName']['Zh_tw'] \
              +" → "+data[0]['EndingStationName']['Zh_tw']
    else:
        msg = "傳送失敗\n"+ "錯誤碼："+ str(r.status_code)

    r.close()
    return msg

def on_connect(client, userdata, flags, rc):
    print("連線結果碼: " + str(rc))
    client.subscribe(ADAFRUIT_IO_USERNAME + "/feeds/" +FEED1)

def on_message(client, userdata, msg):
    s_number = msg.payload.decode('utf-8')
    print(msg.topic + " " + s_number)        
    # 張貼查詢結果
    client.publish(ADAFRUIT_IO_USERNAME + "/feeds/" +FEED2, getTrain(s_number))

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message
client.username_pw_set(ADAFRUIT_IO_USERNAME, ADAFRUIT_IO_KEY)
client.connect("io.adafruit.com", 1883)

client.loop_forever()