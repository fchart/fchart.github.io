import requests   
import time

# 想查詢的車號
s_number = 1167
# 想查詢的車站(1000是台北)
sta_number = 1000

headers = {'user-agent':'Mozilla/5.0'}
# 查詢火車時刻表: https://tdx.transportdata.tw/api/basic/v2/Rail/TRA/LiveBoard/Station/1000?$top=20&$format=JSON
time_url = ("https://tdx.transportdata.tw/api/basic"
            "/v2/Rail/TRA/LiveBoard/Station/"
            + str(sta_number)+"?$top=20&$format=JSON")

r = requests.get(time_url, headers=headers)
if(r.status_code == 200):
    data = r.json()
    # 將車號加入 numbers 串列中
    numbers = []
    for i in range(len(data)):
        numbers.append(data[i]['TrainNo'])    
    print("\n即時班車號碼：", numbers)
    # 有查到對應車號, 顯示延遲時間
    if(str(s_number) in numbers):
        idx = numbers.index(str(s_number))
        print("\n表定發車時間:", data[idx]['ScheduledArrivalTime'])
        print("延遲時間:", data[idx]['DelayTime'], "分鐘")
    
    else:   # 沒有查到對應車號
        print("\n目前無"+str(s_number)+"號火車")    
    
else:
    print("傳送失敗")
    print("錯誤碼：", r.status_code)
    
r.close()

        