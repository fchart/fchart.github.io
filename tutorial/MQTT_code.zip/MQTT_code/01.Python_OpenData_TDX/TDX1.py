import requests   

# 想查詢的車號
s_number = 1202
headers = {'user-agent':'Mozilla/5.0'}
# https://tdx.transportdata.tw/api/basic/v2/Rail/TRA/GeneralTrainInfo/TrainNo/1202?$format=JSON
tdx_url = ("https://tdx.transportdata.tw/api/basic"
           "/v2/Rail/TRA/GeneralTrainInfo/TrainNo/"
           + str(s_number) +"?$format=JSON")

r = requests.get(tdx_url, headers=headers)
if(r.status_code == 200):
    data = r.json()
    print("\n車號:", s_number)
    print(data[0]['StartingStationName']['Zh_tw'] \
          +" → "+data[0]['EndingStationName']['Zh_tw'])
else:
    print("傳送失敗")
    print("錯誤碼：", r.status_code)

r.close()
