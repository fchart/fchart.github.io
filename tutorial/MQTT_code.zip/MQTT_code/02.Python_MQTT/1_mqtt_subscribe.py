import paho.mqtt.client as mqtt

def on_connect(client, userdata, flags, rc):
    print("連線結果碼: " + str(rc))
    # 訂閱主題
    client.subscribe("sensors/12345678/temp")

def on_message(client, userdata, msg):
    # 轉換編碼utf-8來顯示
    print(msg.topic + " " + msg.payload.decode('utf-8'))

# 建立MQTT客戶端物件
client = mqtt.Client()
# 設定連線的回撥函數
client.on_connect = on_connect
# 設定接收訊息的回撥函數
client.on_message = on_message
# 設定登入帳號密碼
# client.username_pw_set("<username>","<password>")
# 建立連線(IP, Port, 連線時間)
client.connect("broker.hivemq.com", 1883, 60)
client.loop_forever()