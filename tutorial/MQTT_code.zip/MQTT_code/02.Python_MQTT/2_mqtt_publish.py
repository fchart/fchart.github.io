import paho.mqtt.client as mqtt
import random
import json  
import datetime 
import time

# 建立MQTT客戶端物件
client = mqtt.Client()
# 設定登入帳號密碼
# client.username_pw_set("<username>","<password>")
# 建立連線(IP, Port, 連線時間)
client.connect("broker.hivemq.com", 1883, 60)

while True:
    temp = random.randint(20, 50)
    t = str(datetime.datetime.now())
    # 建立字典
    payload = {'Temperature' : temp , 'Time' : t}
    # 轉換成JSON字串
    print (json.dumps(payload))
    # 出版主題
    client.publish("sensors/12345678/temp", json.dumps(payload))
    time.sleep(5)