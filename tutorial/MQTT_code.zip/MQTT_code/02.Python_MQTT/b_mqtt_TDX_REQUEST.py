import paho.mqtt.client as mqtt

# 想查詢的車號
s_number = 1202

def on_connect(client, userdata, flags, rc):
    client.subscribe("TDX/12345678/result")

def on_message(client, userdata, msg):
    # 轉換編碼utf-8
    print(msg.topic)
    print(msg.payload.decode('utf-8'))

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message
#client.username_pw_set("myuser","mypassword")
client.connect("broker.hivemq.com", 1883)

# 啟動 loop 執行緒
client.loop_start()
# 張貼 MQTT 訊息
client.publish("TDX/12345678/request", s_number)
